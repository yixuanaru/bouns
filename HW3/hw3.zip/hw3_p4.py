'''def imfine(matrix,x,y,c):
    row=len(matrix)     #輸入的矩陣的行數
    col=len(matrix[0])  #輸入的矩陣的列數
    oc=matrix[x][y]     #
    if oc==c:
        return matrix
    q=[(x,y)]
    v=set()

    while q:
        i,j=q.pop(0)
        if (i,j) in v:
            continue
        v.add((i,j))
        matrix[i][j]=c

        for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            ni,nj=i+dx,j+dy
            if 0<=ni<row and 0<=nj<col and matrix[ni][nj]==oc:
                q.append((ni,nj))
    return matrix'''
'''def imfine(matrix,x,y,c):
    row=len(matrix)
    col=len(matrix[0])
    oc=matrix[x][y]

    def dfs(i, j):
        if i<0 or i>=row or j<0 or j>=col or matrix[i][j]!=oc:
            return
        matrix[i][j]=c
        dfs(i+1,j)
        dfs(i-1,j)
        dfs(i,j+1)
        dfs(i,j-1)
    if oc!=c:
        dfs(x,y)
    return matrix'''
def imfine(matrix,x,y,k):
    oc=matrix[x][y]  #座標原本的顏色
    if oc==k:        #如果輸入的k直接等於初始座標就直接回傳
        return matrix 
    row=len(matrix)
    col=len(matrix[0])
    xyxy=[(x, y)]       #用來存需要改的座標，起始座標也要加進去
    while xyxy:
        i,j=xyxy.pop()  #每次都處理新的座標
        if matrix[i][j]!=oc: #如果這個顏色跟座標的顏色不同我就跳過然後繼續找
            continue
        matrix[i][j]=k 
        for xx,yy in [(1,0),(0,1),(-1,0),(0,-1)]: #檢查像素相鄰的座標
            ii=i+xx 
            jj=j+yy
            if 0<=ii<row and 0<=jj<col: #如果座標都在矩陣裡
                if matrix[ii][jj]==oc:  #如果他跟初始座標的顏色依樣就加進我處存座標的陣列裡面
                    xyxy.append((ii,jj))

    return matrix


n=list(map(int,input("Enter index x,y,k(seperate by whitespace):").split(" ")))
x,y,k=n[0],n[1],n[2]
print("Enter the matrix by multiple lines:")
matrix=[] #用來存使用者輸入的矩陣的矩陣
while True:
    i=input()
    if i=='q':
        break
    matrix.append(list(map(int,i.split())))

#跑function更新矩陣
result=imfine(matrix,x,y,k)

#輸出新的矩陣
for i in range(len(matrix)):
    for j in range(len(matrix[0])):
        if j==len(matrix[0])-1:
           print(matrix[i][j])
           break
        print(matrix[i][j],end=" ")