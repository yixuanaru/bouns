#確認輸入的只有數字且範圍在0到6之間的function
def valid(inputt):
        if len(inputt)==1 and inputt.isdigit():
                num=int(inputt)
                if 0<=num<=6:
                      return True
        return False
#如果滿了要try another
def full(bg,col):
       return bg[0][col]!=' '

print("+---"*7+"+")
for i in range(0,7):
    for row in range(0,8):
           print("|   ", end='')
    print("")
    print("+---" * 7 + "+")
print("  0   1   2   3   4   5   6")
        
       
