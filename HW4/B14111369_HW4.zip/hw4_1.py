import random
#遊戲的背景
def printboard(): 
       print("    a   b   c   d   e   f   g   h   i  ")
       print("  "+"+---"*9+"+")
       for i in range(1):
            for j in range(10):
                print(str(j)+" |  "*9, end='')
                print(" |")
                print("  "+"+---"*9+"+")
printboard()

mines=10 #地雷10顆
